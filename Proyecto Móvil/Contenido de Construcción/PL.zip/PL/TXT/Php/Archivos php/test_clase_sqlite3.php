<?php
echo class_exists('SQLite3') ? "✅ SQLite3 habilitado" : "❌ SQLite3 NO habilitado";
?>
