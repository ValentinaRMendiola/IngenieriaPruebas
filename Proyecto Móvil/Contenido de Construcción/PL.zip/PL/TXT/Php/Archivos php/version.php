<?php
echo phpversion();
?>